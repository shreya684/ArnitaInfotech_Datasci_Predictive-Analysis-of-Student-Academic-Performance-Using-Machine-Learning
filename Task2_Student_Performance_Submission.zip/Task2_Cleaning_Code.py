import pandas as pd

# Load the dataset (change the file name if needed)
df = pd.read_csv("student-mat.csv", sep=";")

# Check the data
print("First five rows:")
print(df.head())
print("\\nMissing values:")
print(df.isnull().sum())
print("\\nDuplicate rows:", df.duplicated().sum())

# Clean the data
df = df.drop_duplicates()
for col in df.select_dtypes(include="object").columns:
    df[col] = df[col].str.strip()

# Check final grade and add labels
df["G3"] = pd.to_numeric(df["G3"], errors="coerce")
df = df[df["G3"].between(0, 20)].copy()
df["Performance"] = df["G3"].apply(
    lambda grade: "Low" if grade <= 9 else ("Average" if grade <= 13 else "High")
)

# Save cleaned and labelled data
df.to_csv("student_math_task2.csv", index=False)
print("\\nCleaned and labelled data saved.")
