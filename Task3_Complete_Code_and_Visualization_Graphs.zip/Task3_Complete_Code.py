# Task 3: Complete Code with Visualization Graphs
# Project: Predictive Analysis of Student Academic Performance Using Machine Learning

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay

# 1. Load the dataset
# Keep this Python file in the same folder as student_math_task2.csv
df = pd.read_csv("student_math_task2.csv")

print("First five rows:")
print(df.head())
print("\nDataset shape:", df.shape)
print("\nMissing values:")
print(df.isnull().sum())
print("\nPerformance label counts:")
print(df["Performance"].value_counts())

# 2. Visualizations
plt.figure(figsize=(7, 4))
df["Performance"].value_counts().reindex(["Low", "Average", "High"], fill_value=0).plot(kind="bar")
plt.title("Number of Students by Performance Level")
plt.xlabel("Performance Level")
plt.ylabel("Number of Students")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

plt.figure(figsize=(7, 4))
df["G3"].plot(kind="hist", bins=11, edgecolor="black")
plt.title("Distribution of Final Grades")
plt.xlabel("Final Grade (G3)")
plt.ylabel("Number of Students")
plt.tight_layout()
plt.show()

plt.figure(figsize=(7, 4))
df.groupby("studytime")["G3"].mean().plot(kind="bar")
plt.title("Average Final Grade by Study Time")
plt.xlabel("Weekly Study Time Category")
plt.ylabel("Average Final Grade")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

plt.figure(figsize=(7, 4))
df.groupby("failures")["G3"].mean().plot(kind="bar")
plt.title("Average Final Grade by Previous Failures")
plt.xlabel("Number of Previous Class Failures")
plt.ylabel("Average Final Grade")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

numeric_cols = df.select_dtypes(include="number").columns
corr = df[numeric_cols].corr()
plt.figure(figsize=(10, 7))
im = plt.imshow(corr, aspect="auto")
plt.colorbar(im, label="Correlation")
plt.xticks(range(len(numeric_cols)), numeric_cols, rotation=90)
plt.yticks(range(len(numeric_cols)), numeric_cols)
plt.title("Correlation Between Numerical Features")
plt.tight_layout()
plt.show()

# 3. Prepare data for machine learning
# Performance was created from G3, so G3 must not be an input feature.
X = df.drop(columns=["Performance", "G3"])
y = df["Performance"]

categorical_cols = X.select_dtypes(include=["object"]).columns.tolist()
numeric_cols = X.select_dtypes(include=["number"]).columns.tolist()

numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])
categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("numeric", numeric_pipeline, numeric_cols),
    ("categorical", categorical_pipeline, categorical_cols)
])

model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced"))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("\nModel accuracy:", round(accuracy_score(y_test, predictions) * 100, 2), "%")
print("\nClassification report:")
print(classification_report(y_test, predictions, zero_division=0))

# 4. Confusion matrix visualization
ConfusionMatrixDisplay.from_predictions(
    y_test, predictions, labels=["Low", "Average", "High"], values_format="d"
)
plt.title("Confusion Matrix - Student Performance Prediction")
plt.tight_layout()
plt.show()

print("\nTask 3 completed.")
